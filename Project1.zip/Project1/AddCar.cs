﻿using Project1.Model;

namespace Project1;

class AddC
{
    static void AddCar(AutoServiceContext context)
    {
        Console.Write("ID Client: ");
        int clientId = int.Parse(Console.ReadLine());

        var client = context.Clients.Find(clientId);
        if (client == null)
        {
            Console.WriteLine("Error: Client not found.");
            return;
        }

        Console.Write("Brand: ");
        string brand = Console.ReadLine();

        Console.Write("Model: ");
        string model = Console.ReadLine();

        Console.Write("Year: ");
        int year = int.Parse(Console.ReadLine());

        var car = new Car
        {
            Brand = brand,
            Model = model,
            Year = year,
            ClientId = clientId
        };

        context.Cars.Add(car);
        context.SaveChanges();

        Console.WriteLine("Done");
    }
}