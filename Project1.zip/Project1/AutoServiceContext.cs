﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.IO;
using Project1.Model;

namespace Project1
{
    public class AutoServiceContext : DbContext
    {
        public DbSet<Client> Clients { get; set; }
        public DbSet<Car> Cars { get; set; }
        public DbSet<Service> Services { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<ServiceCustm> ServiceCustms { get; set; }

        public AutoServiceContext(DbContextOptions<AutoServiceContext> options) : base(options)
        {
        }
    }
}