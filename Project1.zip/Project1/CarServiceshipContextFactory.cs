﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace Project1;

public class CarServiceshipContextFactory : IDesignTimeDbContextFactory<AutoServiceContext>
{
    private string connectionString = "Data Source=localhost;Initial Catalog=CarService;Integrated Security=True;TrustServerCertificate=True";


    public AutoServiceContext CreateDbContext(string[] args)
    {
        var optionsBuilder = new DbContextOptionsBuilder<AutoServiceContext>();
        optionsBuilder.UseSqlServer(connectionString); 
        
        return new AutoServiceContext(optionsBuilder.Options);
    }
}