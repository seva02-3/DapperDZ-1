﻿using Microsoft.EntityFrameworkCore;
using Project1.Model;

namespace Project1;

class Program
{
    private static string connectionString = "Data Source=localhost; Initial Catalog=Data; Integrated Security=true; Trust Server Certificate=true";
    
    static void Main()
    {
        var optionsBuilder = new DbContextOptionsBuilder<AutoServiceContext>();
        optionsBuilder.UseSqlServer(connectionString);
        
        using var db = new AutoServiceContext(optionsBuilder.Options);
      

        while (true)
        {
            Console.WriteLine("\n--- AUTOSERVICE ---");
            Console.WriteLine("1. Register new client");
            Console.WriteLine("2. Add client car");
            Console.WriteLine("3. Create service order");
            Console.WriteLine("4. View client order history");
            Console.WriteLine("0. Exit");
            Console.Write("Choice: ");
            var input = Console.ReadLine();

            switch (input)
            {
                case "1": AddCli.AddClient(db); break;
                case "2": AddCar(db); break;
                case "3": CreateOrder(db); break;
                case "4": ShowC.ShowClientOrders(db); break;
                case "0": return;
            }
        }
    }

    static void RegisterClient(AutoServiceContext db)
    {
        Console.Write("Name: "); var name = Console.ReadLine();
        Console.Write("Surname: "); var surname = Console.ReadLine();
        Console.Write("Phone number: "); var number = Console.ReadLine();

        db.Clients.Add(new Client { Name = name, Surname = surname, Number = number });
        db.SaveChanges();
        Console.WriteLine("Client registered.");
    }

    static void AddCar(AutoServiceContext db)
    {
        Console.Write("Client ID: ");
        if (!int.TryParse(Console.ReadLine(), out var clientId)) return;

        var client = db.Clients.Find(clientId);
        if (client == null) { Console.WriteLine("Client not found."); return; }

        Console.Write("Brand: "); var brand = Console.ReadLine();
        Console.Write("Model: "); var model = Console.ReadLine();
        Console.Write("Year: "); int year = int.Parse(Console.ReadLine());

        db.Cars.Add(new Car { Brand = brand, Model = model, Year = year, ClientId = clientId });
        db.SaveChanges();
        Console.WriteLine("Car added.");
    }

    static void CreateOrder(AutoServiceContext db)
    {
        Console.Write("Client ID: ");
        if (!int.TryParse(Console.ReadLine(), out var clientId)) return;

        var cars = db.Cars.Where(a => a.ClientId == clientId).ToList();
        if (!cars.Any()) { Console.WriteLine("No cars found."); return; }

        Console.WriteLine("Select car:");
        for (int i = 0; i < cars.Count; i++)
            Console.WriteLine($"{i + 1}. {cars[i].Brand} {cars[i].Model}");

        if (!int.TryParse(Console.ReadLine(), out int choice) || choice < 1 || choice > cars.Count)
        {
            Console.WriteLine("Invalid selection.");
            return;
        }

        var order = new Order { ClientId = clientId, CarId = cars[choice - 1].Id, Date = DateTime.Now, Status = "In Progress" };
        db.Orders.Add(order); db.SaveChanges();

        SelectServices(db, order.Id);
    }

    static void SelectServices(AutoServiceContext db, int orderId)
    {
        var services = db.Services.ToList();
        if (!services.Any()) { Console.WriteLine("No services available."); return; }

        decimal total = 0;
        while (true)
        {
            Console.WriteLine("Select service (0 to finish):");
            for (int i = 0; i < services.Count; i++)
                Console.WriteLine($"{i + 1}. {services[i].ServiceName} - {services[i].Price}₽");

            if (!int.TryParse(Console.ReadLine(), out int choice) || choice == 0) break;
            if (choice < 1 || choice > services.Count)
            {
                Console.WriteLine("Invalid service selection.");
                continue;
            }

            var service = services[choice - 1];
            Console.Write("Quantity: ");
            if (!int.TryParse(Console.ReadLine(), out int qty)) continue;

            var sum = service.Price * qty;

            db.ServiceCustms.Add(new ServiceCustm {
                OrderId = orderId,
                ServiceId = service.Id,
                Quantity = qty,
                Sum = sum
            });
            db.SaveChanges();

            total += sum;
        }
        var order = db.Orders.Find(orderId);
        order.Status = "Completed";
        db.SaveChanges();

        Console.WriteLine($"Total order sum: {total}₽");
    }

    static void ViewOrders(AutoServiceContext db)
    {
        Console.Write("Client ID: ");
        if (!int.TryParse(Console.ReadLine(), out var clientId)) return;

        var orders = db.Orders
            .Include(z => z.Car)
            .Include(z => z.ServiceCustms)
            .ThenInclude(zu => zu.Service)
            .Where(z => z.ClientId == clientId)
            .ToList();

        if (!orders.Any())
        {
            Console.WriteLine("No orders found for this client.");
            return;
        }

        foreach (var order in orders)
        {
            Console.WriteLine($"\nOrder #{order.Id} - {order.Date}, {order.Status}");
            Console.WriteLine($"Car: {order.Car.Brand} {order.Car.Model}");

            foreach (var item in order.ServiceCustms)
                Console.WriteLine($" - {item.Service.ServiceName}: {item.Quantity} x {item.Service.Price} = {item.Sum}₽");
        }
    }

    static void AddService(AutoServiceContext db)
    {
        Console.Write("Service name: "); var name = Console.ReadLine();
        Console.Write("Price: ");
        if (!decimal.TryParse(Console.ReadLine(), out var price))
        {
            Console.WriteLine("Invalid price.");
            return;
        }

        db.Services.Add(new Service { ServiceName = name, Price = price });
        db.SaveChanges();
        Console.WriteLine("Service added.");
    }
}