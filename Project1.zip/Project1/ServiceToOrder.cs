﻿using Project1.Model;

namespace Project1;

class ServiceO
{
    public void AddServicesToOrder(AutoServiceContext context, int orderId)
    {
        var services = context.Services.ToList();

        while (true)
        {
            Console.WriteLine("Choice Service:");
            foreach (var s in services)
            {
                Console.WriteLine($"{s.Id}: {s.ServiceName} - {s.Price}$");
            }

            Console.Write("Write a choice service: ");
            int serviceId = int.Parse(Console.ReadLine());
            if (serviceId == 0) break;

            var service = context.Services.Find(serviceId);
            if (service == null)
            {
                Console.WriteLine("Error: Service not found.");
                continue;
            }

            Console.Write("Quantity: ");
            int qty = int.Parse(Console.ReadLine());

            decimal total = service.Price * qty;

            var serviceCustm = new ServiceCustm
            {
                OrderId = orderId,
                ServiceId = serviceId,
                Quantity = qty,
                Sum = total
            };

            context.ServiceCustms.Add(serviceCustm);
            context.SaveChanges();

            Console.WriteLine($"Added Service: {service.ServiceName}, Sum: {total}$");
        }

        Console.WriteLine("Done");
    }
}