﻿using System.ComponentModel.DataAnnotations;

namespace Project1.Model;

public class Order
{
    [Key]

    public int Id { get; set; }
    public int ClientId { get; set; }
    public Client Client { get; set; }

    public int CarId { get; set; }
    public Car Car { get; set; }

    public DateTime Date { get; set; }
    public string Status { get; set; }

    public ICollection<ServiceCustm> ServiceCustms { get; set; }
}