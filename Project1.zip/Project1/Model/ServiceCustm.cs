﻿using System.ComponentModel.DataAnnotations;

namespace Project1.Model;

public class ServiceCustm
{
    [Key]

    public int Id { get; set; }

    public int OrderId { get; set; }
    public Order Order { get; set; }

    public int ServiceId { get; set; }
    public Service Service { get; set; }

    public int Quantity { get; set; }
    public decimal Sum { get; set; }
}