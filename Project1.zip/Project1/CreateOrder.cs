﻿using Project1.Model;

namespace Project1;

class CreateO
{
    static void CreateOrder(AutoServiceContext context)
    {
        Console.Write("ID Client: ");
        int clientId = int.Parse(Console.ReadLine());

        var cars = context.Cars.Where(c => c.ClientId == clientId).ToList();
        if (!cars.Any())
        {
            Console.WriteLine("Error");
            return;
        }

        Console.WriteLine("Choose an option:");
        foreach (var car in cars)
        {
            Console.WriteLine($"{car.Id}: {car.Brand} {car.Model} {car.Year}");
        }

        int carId = int.Parse(Console.ReadLine());

        var order = new Order
        {
            ClientId = clientId,
            CarId = carId,
            Date = DateTime.Now,
            Status = "Created"
        };

        context.Orders.Add(order);
        context.SaveChanges();

        Console.WriteLine("Created order yes or no");
        string answer = Console.ReadLine();
        var service = new ServiceO();
        if (answer.ToLower() == "Yes")
        {
            service.AddServicesToOrder(context, order.Id);
        }
    }
}