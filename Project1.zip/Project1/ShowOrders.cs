﻿namespace Project1;

class ShowC
{
    internal static void ShowClientOrders(AutoServiceContext context)
    {
        Console.Write("Client ID: ");
        int clientId = int.Parse(Console.ReadLine());
    
        var orders = context.Orders
            .Where(o => o.ClientId == clientId)
            .ToList();

        if (!orders.Any())
        {
            Console.WriteLine("Empty order");
            return;
        }

        foreach (var order in orders)
        {
            var car = context.Cars.FirstOrDefault(c => c.Id == order.CarId);
        
            var serviceCustms = context.ServiceCustms
                .Where(sc => sc.OrderId == order.Id)
                .ToList();
        
            var serviceIds = serviceCustms.Select(sc => sc.ServiceId).Distinct().ToList();
            var services = context.Services
                .Where(s => serviceIds.Contains(s.Id))
                .ToDictionary(s => s.Id, s => s);

            Console.WriteLine($"\nID Order: {order.Id}, Date: {order.Date}, Status: {order.Status}");
            Console.WriteLine($"Car: {car?.Brand} {car?.Model} ({car?.Year})");

            decimal totalSum = 0;
            foreach (var sc in serviceCustms)
            {
                var serviceName = services.ContainsKey(sc.ServiceId) ? services[sc.ServiceId].ServiceName : "Empty";
                Console.WriteLine($" - {serviceName} x {sc.Quantity} = {sc.Sum}$");
                totalSum += sc.Sum;
            }

            Console.WriteLine($"Sum: {totalSum}$");
        }
    }
}