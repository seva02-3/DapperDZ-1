﻿using Project1.Model;

namespace Project1;

class AddCli
{
    internal static void AddClient(AutoServiceContext context)
    {
        Console.Write("Name: ");
        string name = Console.ReadLine();

        Console.Write("Surname: ");
        string surname = Console.ReadLine();

        Console.Write("Number: ");
        string number = Console.ReadLine();

        var client = new Client
        {
            Name = name,
            Surname = surname,
            Number = number
        };

        context.Clients.Add(client);
        context.SaveChanges();

        Console.WriteLine("Done");
    }
}